"""Metadata for the pipelines package."""

__title__ = "pipelines"
__description__ = "pipelines - template package"
__version__ = "0.0.1"
__author__ = "PX Data Team"
__author_email__ = "mam@pl-x.de"
__license__ = "Apache 2.0"
__url__ = "<https://your-website>"
